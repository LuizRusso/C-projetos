USE [BancoAula2Dapper]
GO
/****** Object:  Table [dbo].[Categorias]    Script Date: 23/04/2026 21:02:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Categorias](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Nome] [varchar](100) NOT NULL,
	[Ativo] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Produtos]    Script Date: 23/04/2026 21:02:51 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Produtos](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[IDCategoria] [int] NOT NULL,
	[Nome] [varchar](100) NOT NULL,
	[Quantidade] [int] NULL,
	[ValorUnitario] [decimal](10, 2) NULL,
	[Ativo] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Categorias] ON 
GO
INSERT [dbo].[Categorias] ([ID], [Nome], [Ativo]) VALUES (1, N'Informática', 1)
GO
INSERT [dbo].[Categorias] ([ID], [Nome], [Ativo]) VALUES (2, N'Acessórios', 1)
GO
INSERT [dbo].[Categorias] ([ID], [Nome], [Ativo]) VALUES (3, N'Telefonia', 0)
GO
SET IDENTITY_INSERT [dbo].[Categorias] OFF
GO
SET IDENTITY_INSERT [dbo].[Produtos] ON 
GO
INSERT [dbo].[Produtos] ([ID], [IDCategoria], [Nome], [Quantidade], [ValorUnitario], [Ativo]) VALUES (1, 1, N'Mouse', 50, CAST(19.90 AS Decimal(10, 2)), 1)
GO
INSERT [dbo].[Produtos] ([ID], [IDCategoria], [Nome], [Quantidade], [ValorUnitario], [Ativo]) VALUES (2, 2, N'Monitor', 10, CAST(399.99 AS Decimal(10, 2)), 1)
GO
SET IDENTITY_INSERT [dbo].[Produtos] OFF
GO
ALTER TABLE [dbo].[Categorias] ADD  DEFAULT ((1)) FOR [Ativo]
GO
ALTER TABLE [dbo].[Produtos] ADD  DEFAULT ((0)) FOR [Quantidade]
GO
ALTER TABLE [dbo].[Produtos] ADD  DEFAULT ((0)) FOR [ValorUnitario]
GO
ALTER TABLE [dbo].[Produtos] ADD  DEFAULT ((1)) FOR [Ativo]
GO
ALTER TABLE [dbo].[Produtos]  WITH CHECK ADD FOREIGN KEY([IDCategoria])
REFERENCES [dbo].[Categorias] ([ID])
GO
