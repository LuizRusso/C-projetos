﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SGC_Win
{
    public partial class PrincipalForm : Form
    {
        public PrincipalForm()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void PrincipalForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("deseja realmente vossa senhoria sair de tal site?", "Reconsidere", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void PrincipalForm_Load(object sender, EventArgs e)
        {

        }

        private void produtosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProdutolistarForm produtolistarForm = new ProdutolistarForm();
            produtolistarForm.MdiParent = this;
            produtolistarForm.WindowState = FormWindowState.Minimized;
            produtolistarForm.Show();

        }
    }
}
