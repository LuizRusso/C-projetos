﻿namespace SGC_Win
{
    partial class ProdutolistarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.topPanel = new System.Windows.Forms.Panel();
            this.corpoPanel = new System.Windows.Forms.Panel();
            this.rodapePanel = new System.Windows.Forms.Panel();
            this.tituloLabel = new System.Windows.Forms.Label();
            this.filtroNomeLabel = new System.Windows.Forms.Label();
            this.filtroNomeTextBox1 = new System.Windows.Forms.TextBox();
            this.filtroStatusLabel = new System.Windows.Forms.Label();
            this.filtroTodosRadioButton = new System.Windows.Forms.RadioButton();
            this.filtroInativoRadioButton2 = new System.Windows.Forms.RadioButton();
            this.filtroAtivoRadioButton = new System.Windows.Forms.RadioButton();
            this.listarButton = new System.Windows.Forms.Button();
            this.produtosDataGridView1 = new System.Windows.Forms.DataGridView();
            this.produtoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDCategoriaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantidadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorUnitarioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ativoDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.valorTotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoriaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantidadeLabel = new System.Windows.Forms.Label();
            this.fecharButton = new System.Windows.Forms.Button();
            this.alterarButton = new System.Windows.Forms.Button();
            this.inserirButton = new System.Windows.Forms.Button();
            this.Excluirbutton = new System.Windows.Forms.Button();
            this.botoesPanel = new System.Windows.Forms.Panel();
            this.topPanel.SuspendLayout();
            this.corpoPanel.SuspendLayout();
            this.rodapePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.produtosDataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.produtoBindingSource)).BeginInit();
            this.botoesPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // topPanel
            // 
            this.topPanel.BackColor = System.Drawing.Color.LightSteelBlue;
            this.topPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.topPanel.Controls.Add(this.listarButton);
            this.topPanel.Controls.Add(this.filtroAtivoRadioButton);
            this.topPanel.Controls.Add(this.filtroInativoRadioButton2);
            this.topPanel.Controls.Add(this.filtroTodosRadioButton);
            this.topPanel.Controls.Add(this.filtroStatusLabel);
            this.topPanel.Controls.Add(this.filtroNomeTextBox1);
            this.topPanel.Controls.Add(this.filtroNomeLabel);
            this.topPanel.Controls.Add(this.tituloLabel);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPanel.Location = new System.Drawing.Point(0, 0);
            this.topPanel.Name = "topPanel";
            this.topPanel.Size = new System.Drawing.Size(800, 100);
            this.topPanel.TabIndex = 0;
            // 
            // corpoPanel
            // 
            this.corpoPanel.Controls.Add(this.produtosDataGridView1);
            this.corpoPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.corpoPanel.Location = new System.Drawing.Point(0, 100);
            this.corpoPanel.Name = "corpoPanel";
            this.corpoPanel.Size = new System.Drawing.Size(800, 256);
            this.corpoPanel.TabIndex = 1;
            // 
            // rodapePanel
            // 
            this.rodapePanel.Controls.Add(this.quantidadeLabel);
            this.rodapePanel.Controls.Add(this.botoesPanel);
            this.rodapePanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.rodapePanel.Location = new System.Drawing.Point(0, 356);
            this.rodapePanel.Name = "rodapePanel";
            this.rodapePanel.Size = new System.Drawing.Size(800, 94);
            this.rodapePanel.TabIndex = 2;
            this.rodapePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // tituloLabel
            // 
            this.tituloLabel.AutoSize = true;
            this.tituloLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tituloLabel.Location = new System.Drawing.Point(21, 8);
            this.tituloLabel.Name = "tituloLabel";
            this.tituloLabel.Size = new System.Drawing.Size(168, 42);
            this.tituloLabel.TabIndex = 0;
            this.tituloLabel.Text = "Produtos";
            // 
            // filtroNomeLabel
            // 
            this.filtroNomeLabel.AutoSize = true;
            this.filtroNomeLabel.Location = new System.Drawing.Point(25, 50);
            this.filtroNomeLabel.Name = "filtroNomeLabel";
            this.filtroNomeLabel.Size = new System.Drawing.Size(127, 13);
            this.filtroNomeLabel.TabIndex = 1;
            this.filtroNomeLabel.Text = "Digite o nome do Produto";
            this.filtroNomeLabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // filtroNomeTextBox1
            // 
            this.filtroNomeTextBox1.Location = new System.Drawing.Point(28, 66);
            this.filtroNomeTextBox1.Name = "filtroNomeTextBox1";
            this.filtroNomeTextBox1.Size = new System.Drawing.Size(224, 20);
            this.filtroNomeTextBox1.TabIndex = 2;
            // 
            // filtroStatusLabel
            // 
            this.filtroStatusLabel.AutoSize = true;
            this.filtroStatusLabel.Location = new System.Drawing.Point(269, 51);
            this.filtroStatusLabel.Name = "filtroStatusLabel";
            this.filtroStatusLabel.Size = new System.Drawing.Size(37, 13);
            this.filtroStatusLabel.TabIndex = 3;
            this.filtroStatusLabel.Text = "Status";
            this.filtroStatusLabel.Click += new System.EventHandler(this.label3_Click);
            // 
            // filtroTodosRadioButton
            // 
            this.filtroTodosRadioButton.AutoSize = true;
            this.filtroTodosRadioButton.Location = new System.Drawing.Point(272, 67);
            this.filtroTodosRadioButton.Name = "filtroTodosRadioButton";
            this.filtroTodosRadioButton.Size = new System.Drawing.Size(55, 17);
            this.filtroTodosRadioButton.TabIndex = 4;
            this.filtroTodosRadioButton.Text = "Todos";
            this.filtroTodosRadioButton.UseVisualStyleBackColor = true;
            // 
            // filtroInativoRadioButton2
            // 
            this.filtroInativoRadioButton2.AutoSize = true;
            this.filtroInativoRadioButton2.Location = new System.Drawing.Point(394, 67);
            this.filtroInativoRadioButton2.Name = "filtroInativoRadioButton2";
            this.filtroInativoRadioButton2.Size = new System.Drawing.Size(57, 17);
            this.filtroInativoRadioButton2.TabIndex = 5;
            this.filtroInativoRadioButton2.Text = "Inativo";
            this.filtroInativoRadioButton2.UseVisualStyleBackColor = true;
            // 
            // filtroAtivoRadioButton
            // 
            this.filtroAtivoRadioButton.AutoSize = true;
            this.filtroAtivoRadioButton.Checked = true;
            this.filtroAtivoRadioButton.Location = new System.Drawing.Point(333, 67);
            this.filtroAtivoRadioButton.Name = "filtroAtivoRadioButton";
            this.filtroAtivoRadioButton.Size = new System.Drawing.Size(49, 17);
            this.filtroAtivoRadioButton.TabIndex = 6;
            this.filtroAtivoRadioButton.TabStop = true;
            this.filtroAtivoRadioButton.Text = "Ativo";
            this.filtroAtivoRadioButton.UseVisualStyleBackColor = true;
            // 
            // listarButton
            // 
            this.listarButton.Location = new System.Drawing.Point(457, 64);
            this.listarButton.Name = "listarButton";
            this.listarButton.Size = new System.Drawing.Size(75, 23);
            this.listarButton.TabIndex = 7;
            this.listarButton.Text = "Listar";
            this.listarButton.UseVisualStyleBackColor = true;
            // 
            // produtosDataGridView1
            // 
            this.produtosDataGridView1.AllowUserToAddRows = false;
            this.produtosDataGridView1.AllowUserToDeleteRows = false;
            this.produtosDataGridView1.AutoGenerateColumns = false;
            this.produtosDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.produtosDataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.iDCategoriaDataGridViewTextBoxColumn,
            this.nomeDataGridViewTextBoxColumn,
            this.quantidadeDataGridViewTextBoxColumn,
            this.valorUnitarioDataGridViewTextBoxColumn,
            this.ativoDataGridViewCheckBoxColumn,
            this.valorTotalDataGridViewTextBoxColumn,
            this.categoriaDataGridViewTextBoxColumn});
            this.produtosDataGridView1.DataSource = this.produtoBindingSource;
            this.produtosDataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.produtosDataGridView1.Location = new System.Drawing.Point(0, 0);
            this.produtosDataGridView1.Name = "produtosDataGridView1";
            this.produtosDataGridView1.ReadOnly = true;
            this.produtosDataGridView1.Size = new System.Drawing.Size(800, 256);
            this.produtosDataGridView1.TabIndex = 0;
            // 
            // produtoBindingSource
            // 
            this.produtoBindingSource.DataSource = typeof(SGC_Negocio.Mapeamento.Produto);
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // iDCategoriaDataGridViewTextBoxColumn
            // 
            this.iDCategoriaDataGridViewTextBoxColumn.DataPropertyName = "IDCategoria";
            this.iDCategoriaDataGridViewTextBoxColumn.HeaderText = "IDCategoria";
            this.iDCategoriaDataGridViewTextBoxColumn.Name = "iDCategoriaDataGridViewTextBoxColumn";
            this.iDCategoriaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nomeDataGridViewTextBoxColumn
            // 
            this.nomeDataGridViewTextBoxColumn.DataPropertyName = "Nome";
            this.nomeDataGridViewTextBoxColumn.HeaderText = "Nome";
            this.nomeDataGridViewTextBoxColumn.Name = "nomeDataGridViewTextBoxColumn";
            this.nomeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantidadeDataGridViewTextBoxColumn
            // 
            this.quantidadeDataGridViewTextBoxColumn.DataPropertyName = "Quantidade";
            this.quantidadeDataGridViewTextBoxColumn.HeaderText = "Quantidade";
            this.quantidadeDataGridViewTextBoxColumn.Name = "quantidadeDataGridViewTextBoxColumn";
            this.quantidadeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // valorUnitarioDataGridViewTextBoxColumn
            // 
            this.valorUnitarioDataGridViewTextBoxColumn.DataPropertyName = "ValorUnitario";
            this.valorUnitarioDataGridViewTextBoxColumn.HeaderText = "ValorUnitario";
            this.valorUnitarioDataGridViewTextBoxColumn.Name = "valorUnitarioDataGridViewTextBoxColumn";
            this.valorUnitarioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ativoDataGridViewCheckBoxColumn
            // 
            this.ativoDataGridViewCheckBoxColumn.DataPropertyName = "Ativo";
            this.ativoDataGridViewCheckBoxColumn.HeaderText = "Ativo";
            this.ativoDataGridViewCheckBoxColumn.Name = "ativoDataGridViewCheckBoxColumn";
            this.ativoDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // valorTotalDataGridViewTextBoxColumn
            // 
            this.valorTotalDataGridViewTextBoxColumn.DataPropertyName = "ValorTotal";
            this.valorTotalDataGridViewTextBoxColumn.HeaderText = "ValorTotal";
            this.valorTotalDataGridViewTextBoxColumn.Name = "valorTotalDataGridViewTextBoxColumn";
            this.valorTotalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // categoriaDataGridViewTextBoxColumn
            // 
            this.categoriaDataGridViewTextBoxColumn.DataPropertyName = "Categoria";
            this.categoriaDataGridViewTextBoxColumn.HeaderText = "Categoria";
            this.categoriaDataGridViewTextBoxColumn.Name = "categoriaDataGridViewTextBoxColumn";
            this.categoriaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantidadeLabel
            // 
            this.quantidadeLabel.AutoSize = true;
            this.quantidadeLabel.Location = new System.Drawing.Point(39, 28);
            this.quantidadeLabel.Name = "quantidadeLabel";
            this.quantidadeLabel.Size = new System.Drawing.Size(16, 13);
            this.quantidadeLabel.TabIndex = 0;
            this.quantidadeLabel.Text = "...";
            // 
            // fecharButton
            // 
            this.fecharButton.Location = new System.Drawing.Point(340, 38);
            this.fecharButton.Name = "fecharButton";
            this.fecharButton.Size = new System.Drawing.Size(75, 23);
            this.fecharButton.TabIndex = 1;
            this.fecharButton.Text = "Fechar";
            this.fecharButton.UseVisualStyleBackColor = true;
            // 
            // alterarButton
            // 
            this.alterarButton.Location = new System.Drawing.Point(259, 38);
            this.alterarButton.Name = "alterarButton";
            this.alterarButton.Size = new System.Drawing.Size(75, 23);
            this.alterarButton.TabIndex = 2;
            this.alterarButton.Text = "Alterar";
            this.alterarButton.UseVisualStyleBackColor = true;
            // 
            // inserirButton
            // 
            this.inserirButton.Location = new System.Drawing.Point(178, 38);
            this.inserirButton.Name = "inserirButton";
            this.inserirButton.Size = new System.Drawing.Size(75, 23);
            this.inserirButton.TabIndex = 3;
            this.inserirButton.Text = "inserir";
            this.inserirButton.UseVisualStyleBackColor = true;
            // 
            // Excluirbutton
            // 
            this.Excluirbutton.Location = new System.Drawing.Point(97, 38);
            this.Excluirbutton.Name = "Excluirbutton";
            this.Excluirbutton.Size = new System.Drawing.Size(75, 23);
            this.Excluirbutton.TabIndex = 4;
            this.Excluirbutton.Text = "Excluir";
            this.Excluirbutton.UseVisualStyleBackColor = true;
            // 
            // botoesPanel
            // 
            this.botoesPanel.Controls.Add(this.fecharButton);
            this.botoesPanel.Controls.Add(this.alterarButton);
            this.botoesPanel.Controls.Add(this.inserirButton);
            this.botoesPanel.Controls.Add(this.Excluirbutton);
            this.botoesPanel.Location = new System.Drawing.Point(361, 0);
            this.botoesPanel.Name = "botoesPanel";
            this.botoesPanel.Size = new System.Drawing.Size(439, 94);
            this.botoesPanel.TabIndex = 5;
            // 
            // ProdutolistarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.corpoPanel);
            this.Controls.Add(this.topPanel);
            this.Controls.Add(this.rodapePanel);
            this.Name = "ProdutolistarForm";
            this.Text = "Lista de Produtos";
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            this.corpoPanel.ResumeLayout(false);
            this.rodapePanel.ResumeLayout(false);
            this.rodapePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.produtosDataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.produtoBindingSource)).EndInit();
            this.botoesPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.Panel corpoPanel;
        private System.Windows.Forms.Panel rodapePanel;
        private System.Windows.Forms.Label tituloLabel;
        private System.Windows.Forms.TextBox filtroNomeTextBox1;
        private System.Windows.Forms.Label filtroNomeLabel;
        private System.Windows.Forms.RadioButton filtroTodosRadioButton;
        private System.Windows.Forms.Label filtroStatusLabel;
        private System.Windows.Forms.Button listarButton;
        private System.Windows.Forms.RadioButton filtroAtivoRadioButton;
        private System.Windows.Forms.RadioButton filtroInativoRadioButton2;
        private System.Windows.Forms.DataGridView produtosDataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDCategoriaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorUnitarioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ativoDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorTotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoriaDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource produtoBindingSource;
        private System.Windows.Forms.Button Excluirbutton;
        private System.Windows.Forms.Button inserirButton;
        private System.Windows.Forms.Button alterarButton;
        private System.Windows.Forms.Button fecharButton;
        private System.Windows.Forms.Label quantidadeLabel;
        private System.Windows.Forms.Panel botoesPanel;
    }
}