﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SGC_Win
{
    public partial class SplashForm : Form
    {
        public SplashForm()
        {
            InitializeComponent();

            
        }

        private void SplashForm_Load(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 5;

            for (int i = 1; i <= 5; i++)
            {
                label2.Text = $"Carregando... Fase {i} de 5";
                progressBar1.Value = i;
                Application.DoEvents();
                System.Threading.Thread.Sleep(500);
            }

            progressBar1.Value = 5;
            Application.DoEvents();
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void SplashForm_Shown(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 5;
            var msg = "Iniciando...;Conectando ao banco...;Ajustando visual...; Finalizando...; Abrindo!".Split(';');
            for (int i = 1; i <= 5; i++)
            {
                label2.Text = $"{msg[i - 1]} {i} de 5";
                progressBar1.Value = i;
                Application.DoEvents();
                System.Threading.Thread.Sleep(500);
            }
        }
    }
}
