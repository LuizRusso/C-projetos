﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SGC_Win
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            SplashForm splashFrom = new SplashForm();
            splashFrom.Show();
            Application.DoEvents();

            System.Threading.Thread.Sleep(3000);
            splashFrom.Close();


            

            Application.Run(new PrincipalForm());
        }
    }
}
