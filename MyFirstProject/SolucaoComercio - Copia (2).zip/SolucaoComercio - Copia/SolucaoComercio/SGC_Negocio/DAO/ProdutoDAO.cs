﻿using Dapper;
using SGC_Negocio.Mapeamento;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SGC_Negocio.DAO
{
    public class ProdutoDAO : Conexao
    {
        public Produto Buscar(int id)
        {
            var resp = banco.Query<Produto>
                ("select * " +
                "from Produtos " +
                "where ID = @pID",
                new { pID = id }).SingleOrDefault();

            if (resp != null)
                resp.Categoria = new CategoriaDAO().Buscar(resp.IDCategoria);

            return resp;
        }

        public List<Produto> Listar()
        {
            //vai ao banco e tras todos os produtos
            var lista = banco.Query<Produto>
                ("select * from Produtos").ToList();

            //ordena em memória 
            lista = lista.OrderBy(o => o.Nome).ToList();

            CategoriaDAO categoriaDAO = new CategoriaDAO();
            foreach (var item in lista)
            {
                item.Categoria = categoriaDAO.Buscar(item.IDCategoria);
            }

            return lista;
        }

        public bool Excluir(int id)
        {
            try
            {
                var resp = banco.Execute(
                    "delete from produtos where id = @pID",
                    new { pID = id });
                return resp == 1;
            }
            catch
            {
                return false;
            }
        }

        private int Inserir(Produto produto)
        {
            return banco.Query<Int32>
                ("Insert into Produtos " +
                "(IDCategoria, Nome, Quantidade, ValorUnitario,Ativo) " +
                "VALUES " +
                "(@IDCategoria, @Nome, @Quantidade, @ValorUnitario,@Ativo) " +
                 "select @@IDENTITY",
                produto).Single();
        }

        private int Alterar(Produto produto)
        {
            var resp = banco.Execute(
                "Update Produtos SET " +
                "IDCategoria = @IDCategoria, Nome = @Nome, " +
                "Quantidade = @Quantidade, ValorUnitario = @ValorUnitario, " +
                "Ativo = @Ativo " +
                "Where ID = @ID");

            return resp == 0 ? 0 : produto.ID;
        }

        public Int32 Salvar(Produto produto)
        {
            if (produto == null || produto.Nome.Trim().Length == 0)
                return 0;

            if (produto.ID == 0)
                return Inserir(produto);
            else
                return Alterar(produto);
        }
    }
}
