﻿using Dapper;
using SGC_Negocio.Mapeamento;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SGC_Negocio.DAO
{
    public class ClienteDAO : Conexao
    {
        public Cliente Buscar(int id)
        {
            var resp = banco.Query<Cliente>
                ("select * " +
                "from Clientes " +
                "where ID = @pID",
                new { pID = id }).SingleOrDefault();

            if (resp != null)
                resp.Cidade = new CidadeDAO().Buscar(resp.IDCidade);

            return resp;
        }

        public List<Cliente> Listar()
        {
            var lista = banco.Query<Cliente>
                ("select * from Clientes").ToList();

            //ordena em memória 
            lista = lista.OrderBy(o => o.Nome).ToList();

            CidadeDAO cidadeDAO = new CidadeDAO();
            foreach (var item in lista)
            {
                item.Cidade = cidadeDAO.Buscar(item.IDCidade);
            }

            return lista;
        }

        public bool Excluir(int id)
        {
            try
            {
                var resp = banco.Execute(
                    "delete from Clientes where id = @pID",
                    new { pID = id });
                return resp == 1;
            }
            catch
            {
                return false;
            }
        }

        private int Inserir(Cliente cliente)
        {
            return banco.Query<Int32>
                ("Insert into Clientes " +
                "(IDCidade, Nome, NomeSocial, Sexo, DataNascimento, CPF,Ativo) " +
                "VALUES " +
                "(@IDCidade, @Nome, @NomeSocial, @Sexo, @DataNascimento, @CPF, @Ativo) " +
                "select @@IDENTITY",
                cliente).Single();
        }

        private int Alterar(Cliente cliente)
        {
            var resp = banco.Execute(
                "Update Clientes SET " +
                "IDCidade = @IDCidade, Nome = @Nome, NomeSocial = @NomeSocial, " +
                "Sexo = @Sexo, DataNascimento = @DataNascimento, CPF = @CPF, " +
                "Ativo = @Ativo " +
                "Where ID = @ID");

            return resp == 0 ? 0 : cliente.ID;
        }

        public Int32 Salvar(Cliente cliente)
        {
            if (cliente == null || cliente.Nome.Trim().Length == 0)
                return 0;

            if (cliente.ID == 0)
                return Inserir(cliente);
            else
                return Alterar(cliente);
        }
    }
}
