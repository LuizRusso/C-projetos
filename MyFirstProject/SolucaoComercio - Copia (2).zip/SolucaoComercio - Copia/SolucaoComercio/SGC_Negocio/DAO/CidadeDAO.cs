﻿using Dapper;
using SGC_Negocio.Mapeamento;
using System.Collections.Generic;
using System.Linq;

namespace SGC_Negocio.DAO
{
    public class CidadeDAO : Conexao
    {
        public List<Cidade> Listar()
        {
            string sql = "select * from Cidades ";
            return banco.Query<Cidade>(sql).ToList();
        }

        public Cidade Buscar(int id)
        {
            return banco.Query<Cidade>(
                "select * " +
                "from Cidades " +
                "where id = @pID",
                new { pID = id }
                ).SingleOrDefault();
        }
    }
}