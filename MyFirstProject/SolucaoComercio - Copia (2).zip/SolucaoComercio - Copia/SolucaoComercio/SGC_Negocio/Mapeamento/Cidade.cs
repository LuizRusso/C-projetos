﻿namespace SGC_Negocio.Mapeamento
{
    public class Cidade
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string UF { get; set; }
    }
}
