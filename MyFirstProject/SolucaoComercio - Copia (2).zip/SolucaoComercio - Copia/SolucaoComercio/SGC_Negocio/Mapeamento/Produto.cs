﻿namespace SGC_Negocio.Mapeamento
{
    public class Produto
    {
        public int ID { get; set; }
        public int IDCategoria { get; set; }
        public string Nome { get; set; }
        public int Quantidade { get; set; }
        public decimal ValorUnitario { get; set; }
        public bool Ativo { get; set; }

        //virtuais - não são campos no banco

        public decimal ValorTotal { get { return  ValorUnitario * Quantidade; } }

        public Categoria Categoria { get; set; }
    }
}
