﻿using System;

namespace SGC_Negocio.Mapeamento
{
    public class Cliente
    {
        public int ID { get; set; }
        public int IDCidade { get; set; }
        public string Nome { get; set; }
        public string NomeSocial { get; set; }
        public string Sexo { get; set; }
        public DateTime DataNascimento { get; set; }
        public string CPF { get; set; }
        public bool Ativo { get; set; }

        //método virtuais - não estão no banco 
        public Cidade Cidade { get; set; }

        public int Idade
        {
            get
            {
                DateTime hoje = DateTime.Today;

                // Validação básica para datas futuras
                if (DataNascimento > hoje)
                    return -1;

                int anos = hoje.Year - DataNascimento.Year;
                int meses = hoje.Month - DataNascimento.Month;

                // Ajuste se o mês atual for anterior ao mês de nascimento 
                // ou se for o mesmo mês mas o dia atual for anterior ao dia de nascimento
                if (hoje.Day < DataNascimento.Day)
                {
                    meses--;
                }

                if (meses < 0)
                {
                    anos--;
                    meses += 12;
                }

                return anos;
            }
        }
    }
}