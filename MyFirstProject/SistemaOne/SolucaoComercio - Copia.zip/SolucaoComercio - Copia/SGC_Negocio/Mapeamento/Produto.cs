﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGC_Negocio.Mapeamento
{
    public class Produto
    {
        public int Id { get; set; }
        public int IDCategoria { get; set; }

        public string Nome { get; set; }

        public int Quantidade { get; set; }

        public decimal ValorUnitario { get; set; }

        public bool Ativo { get; set; }

        //virtuais -- nao sao campos de dados 

        public decimal ValorTotal { get {return ValorUnitario* Quantidade; } }

        public Categoria Categoria { get; set; }
    }
}
