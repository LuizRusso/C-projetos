﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGC_Negocio
{
    public class Conexao
    {
        public SqlConnection banco = null;
        public Conexao()
        {
            banco = new SqlConnection("Data Source=LAB511\\MSSQLSERVER1;Initial Catalog=BancoAula2Dapper;Integrated Security=true;Column Encryption Setting=enabled;");
        }
    }
}