﻿using Dapper;
using SGC_Negocio;
using SGC_Negocio.Mapeamento;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

public class CategoriaDAO : Conexao
{
    public List<Categoria> Listar(bool? soAtivos = null)
    {
        string sql =
            "select " +
            "* " +
            "from Categorias " +
            "where 1 = 1 ";

        if (soAtivos != null)
            sql += "ativo = @ativo ";

        sql += "order by Nome";

        return banco.Query<Categoria>
            (sql,
            new { ativo = soAtivos != null ? soAtivos.Value : false }
            ).ToList();

    
}
    public Categoria Buscar(int id)
    {
        return banco.Query<Categoria>(
            "select * " +
            "from Categorias " +
            "where id = @id",
            new { id = id }
            ).SingleOrDefault();
    }
}